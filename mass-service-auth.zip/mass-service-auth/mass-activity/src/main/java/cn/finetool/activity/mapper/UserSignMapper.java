package cn.finetool.activity.mapper;

import cn.finetool.common.po.UserSign;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserSignMapper extends BaseMapper<UserSign> {
}
