package cn.finetool.common.constant;

public class MqTTL {

    /** ======== 5 分钟 ======== */
    public static final long FIVE_MINUTES = 300000;
}
