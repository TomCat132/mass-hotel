package cn.finetool.recharge.mapper;

import cn.finetool.common.po.RechargePlans;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RechargePlanMapper extends BaseMapper<RechargePlans> {
}
